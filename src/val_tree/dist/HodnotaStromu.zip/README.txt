Trees
==============
Použití
--------------
1. Vyplnit soubor trees.xlsm
2. Spustit program Hodnota_stromu.exe, vložit cestu k souboru trees.xlsm a stisknout Run
3. Po krátké chvíly by měl program vytovřit soubor s výstupem

E - V případě problémů s výpočtem kontaktovat mě a ideálně zaslat vyplněný trees.xlsm. Obratem o/upravím.

Possible Improvements [TODO]
----------------------------


Reference
----------

  [1]: https://www.ochranaprirody.cz/res/archive/434/075767.pdf?seek=1648738598
  [2]: https://ocenovanidrevin.nature.cz/

